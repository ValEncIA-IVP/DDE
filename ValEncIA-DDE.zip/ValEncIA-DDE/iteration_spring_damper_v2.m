%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This Matlab-script contains the simulation of 
% the Example in Fig. 4, Case P2 of the paper
% "Verified Integration of Differential Equations with Discrete Delay" 
% by Andreas Rauh and Ekaterina Auer
%
% To execute the simulation, Intlab needs to be installed on your system
%
% The simulation is tested with Intlab V12, Matlab R2019b
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all
close all

startintlab;
warning on

clc
format long
intvalinit('displayinfsup')

intvalinit('SharpIVmult');

% specify nominal system parameters
a21 = -200;
a22 = -15;
a23 = -400;
a33 = -200;

b3 = 10;

b_y = [0;0;b3];

% specify parameter uncertainty
unc1 = infsup(0.995,1.005);
unc2 = infsup(0.995,1.005);

% determine tight bounds of the uncertain system matrix
A_y = sys_matr(a21,a22,a23,a33,unc1,unc2);

Ay = mid(A_y);
by = mid(b_y);

xy_0 = [1; 0; 0.5];

% controller gain
ky_T = [0 -0.8 0]

% compute point-valued approximation of eigenvectors to perform a change of
% coordinates: The change of coordinates is based on the delay-free system
% part
[v_y,d_y]=eig(Ay);

v_y = midrad(v_y,0);

NN = 100;
% determine tight bounds of the transformed uncertain system matrix
[A_y,A_y_re,A_y_im] = trafo_Ay(0*b_y,ky_T,a21,a22,a23,a33,unc1,unc2,v_y,NN);  % NN subdivions of parameter intervals
[A_y1,A_y_re1,A_y_im1] = trafo_Ay(0*b_y,ky_T,a21,a22,a23,a33,unc1,unc2,v_y,1);% no subdivision

A_y = intersect(A_y,A_y1);
A_y = intersect(A_y,intersect(A_y_re,A_y_re1)+1i*intersect(A_y_im,A_y_im1));

% Tronsformation of initial conditions (performed in interval analysis
% using Intlab)
x0 = xy_0; 
x0 = inv(v_y)*x0;

T_mat = intval(v_y)

%%

nx = 3;

lambda_vec = [intval(0);intval(0);intval(0)];
x0_vec = [x0, x0];

% Discretization step size
delta_t = 1e-5;
NN1 = 2000;
MM1 = 1e1;

% delay
lag = intval(MM1*delta_t);

A1 = A_y; %transformed delay-free part
A2 = -inv(v_y)*b_y*ky_T*v_y; %tranformed delayed system part

lambda = lambda_vec(:,1);
if ~isreal(A1)
    lambda = cintval(lambda);
end
t_discr = [-MM1:NN1*MM1]*delta_t;
t_discr = infsup(t_discr(1:end-1),t_discr(2:end));

% initialization of a vector of solution parameters
lambda_vec = lambda*ones(size(t_discr));
lambda_vec(:,~(sup(t_discr)<=0)) = nan;

indx = find(sup(t_discr)<=0);

t_start = 0;

t_int = t_start + infsup(0,delta_t);
t_int_del = t_int - inf(lag);

x_vec_start = intval(x0);
x_vec_int = intval([]);
for i=1:indx(end),
    x_vec_start = [x_vec_start, x_vec_start(:,end).*exp(lambda_vec(:,i)*delta_t)];
    x_vec_int   = [x_vec_int, x_vec_start(:,i).*exp(lambda_vec(:,i)*infsup(0,delta_t))];
end;


flag_break = 0;

% Time loop
indx_lambda = indx(end);
while 1

    lambda = lambda_vec(:,indx_lambda);
    time_alt = t_int_del;
    time_interersect = intersect(t_discr,time_alt.*ones(size(t_discr)));
    indx_alt = isfinite(time_interersect);
    time_alt_vec = time_interersect(indx_alt)-inf(t_discr(indx_alt));
    
    x_alt = x_vec_start(:,indx_alt).*exp(lambda_vec(:,indx_alt).*time_alt_vec);
    
    time_neu = t_int;
    time_interersect = intersect(t_discr,time_neu.*ones(size(t_discr)));
    indx_neu = (isfinite(time_interersect))&(diam(time_interersect)>1e-3*delta_t);
    time_neu_vec = time_interersect(indx_neu)-inf(t_discr(indx_neu));
    
    % max. 100 iterations according to eq. (23) in "Verified Integration of
    % Differential Equations with Discrete Delay"  
    for i=1:100,
        lambda_neu = intval([]);
        
        lambda_vec(:,indx_neu) = lambda;
        x_neu = x_vec_start(:,indx_neu).*exp(lambda_vec(:,indx_neu).*time_neu_vec);
        
        lambda_neu_vec = intval([]);
        for j=1:nx
            xx_temp = x_neu./x_neu(j);
            xx_temp(j) = 1;
            temp_var = A1(j,:)*xx_temp;
            lambda_neu_vec(j,1) = temp_var;
        end
        lambda_neu_vec = repmat(lambda_neu_vec,1,size(x_alt,2)) + (A2*x_alt)./x_neu;
        
        lambda_neu = hull(min(inf(lambda_neu_vec),[],2),max(sup(lambda_neu_vec),[],2));
        
        if all(in(lambda_neu,lambda)&isfinite(lambda_neu))
            if all((diam(lambda)-diam(lambda_neu))<1e-7),
                lambda = lambda_neu;
                lambda_vec(:,indx_neu) = lambda;
                break;
            end;
            lambda = lambda_neu;
            lambda_vec(:,indx_neu) = lambda;
        else
            lambda = hull(lambda_neu,lambda);
            lambda_vec(:,indx_neu) = lambda;
            if i==100,
                flag_break = 1;
                warning('no convergence')
                break
            end;
        end;
    end;
    lambda
    
    if flag_break==1
        break;
    end
    
    x_vec_start = [x_vec_start, x_vec_start(:,end).*exp(lambda*delta_t)];
    x_vec_int   = [x_vec_int, x_vec_start(:,end-1).*exp(lambda*infsup(0,delta_t))];

    if length(x_vec_int)==length(t_discr)
        break;
    end
    
    t_int = t_discr(find(indx_neu)+1);
    t_int_del = t_int - lag;
    
    indx_lambda = find(indx_neu);
    indx_lambda = indx_lambda(end);
end;

% Backward trnsformation of the solution
x_real = intval([]);
for i = 1:size(x_vec_start,2),
    x_real(:,i) = real(T_mat*x_vec_start(:,i));
end;

t_vec = inf(t_discr(1:size(x_vec_start,2))); 

% visulize the lower and upper state bounds
figure;
hold on;
plot(t_vec,inf(x_real(1,:)),'k','LineWidth',2);
plot(t_vec,sup(x_real(1,:)),'k','LineWidth',2);
hold off;

figure;
hold on;
plot(t_vec,inf(x_real(2,:)),'k','LineWidth',2);
plot(t_vec,sup(x_real(2,:)),'k','LineWidth',2);
hold off;

figure;
hold on;
plot(t_vec,inf(x_real(3,:)),'k','LineWidth',2);
plot(t_vec,sup(x_real(3,:)),'k','LineWidth',2);
hold off;
