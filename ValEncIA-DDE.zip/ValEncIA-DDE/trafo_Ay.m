function [A_y_tr,A_y_tr_tmp_re,A_y_tr_tmp_im] = trafo_Ay(b_y,ky_T,a21,a22,a23,a33,unc1,unc2,v_y,NN)

unc1_vec = linspace(inf(unc1),sup(unc1),NN+1);
unc1_vec = unc1_vec(:);
unc2_vec = linspace(inf(unc2),sup(unc2),NN+1);
unc2_vec = unc2_vec(:).';
unc1_vec = repmat(unc1_vec,1,NN);
unc2_vec = repmat(unc2_vec,NN,1);

unc1_vec = unc1_vec(:);
unc2_vec = unc2_vec(:);

inv_v_y = inv(v_y);

for i=1:length(unc1_vec)
    A_y1 = sys_matr(a21,a22,a23,a33,unc1_vec(i),unc2_vec(i));
    if i==1
        A_y_tr_tmp = inv_v_y*A_y1*v_y;
        A_y_tr_tmp_re = real(A_y_tr_tmp);
        A_y_tr_tmp_im = imag(A_y_tr_tmp);
    else
        A_y_tr_tmp = inv_v_y*A_y1*v_y;
        A_y_tr_tmp_re = hull(A_y_tr_tmp_re,real(A_y_tr_tmp));
        A_y_tr_tmp_im = hull(A_y_tr_tmp_im,imag(A_y_tr_tmp));
    end
end
A_y_tr = A_y_tr_tmp_re+1i*A_y_tr_tmp_im - inv_v_y*b_y*ky_T*v_y;

A_y_tr_tmp_re = A_y_tr_tmp_re-real(inv_v_y*b_y*ky_T*v_y);
A_y_tr_tmp_im = A_y_tr_tmp_im-imag(inv_v_y*b_y*ky_T*v_y);