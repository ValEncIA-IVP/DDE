function A_y = sys_matr(a21,a22,a23,a33,unc1,unc2)

A_y = [0 1 0;
     unc1*a21 unc2*a22 a23;
     0 0 a33];